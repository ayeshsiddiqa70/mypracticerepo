package Strings;

import java.util.Arrays;

public class Anagram {

    public static void main(String[] args) {

        String str1 = "brag";
        String str2 = "grab";

        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();

        if(str1.length() != str2.length()) {

            System.out.println("Both strings are not anagram");

        } else {

            char[] ch1 = str1.toCharArray();
            char[] ch2 = str2.toCharArray();

            Arrays.sort(ch1);
            Arrays.sort(ch2);

            boolean flag = Arrays.equals(ch1, ch2);

            if(flag == true) {

                System.out.println("Anagram");

            } else {

                System.out.println("Not Anagram");
            }
        }
    }
}
package Strings;

public class ReverseSentence {

    public static void main(String[] args) {

     /*   String str = "java is easy";

        String[] s1 = str.split(" ");

        for(int i = s1.length - 1; i >= 0; i--) {

            System.out.print(s1[i] + " ");
        }
    }*/
    	
    	
    	String str = "java is easy";
    	String[] s1 = str.split(" ");
    	for(String x:s1) {
    		String rev="";
    		for(int i=x.length()-1;i>=0;i--) {
    			rev=rev+x.charAt(i);
    		}
    		System.out.println(rev+"");
    	}
    	
}}
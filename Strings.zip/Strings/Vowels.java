package Strings;

public class Vowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String str="Welcome to java";
        int count =0;
        
        for(int i=0; i<str.length();i++) {
        	char ch=str.charAt(i);
        	
        	if(ch=='a' || ch=='e'|| ch=='i'|| ch=='o'|| ch=='u') {
        		count ++;
        		
        		
        	}
        }
        
        System.out.println("vowels are" +count);
	}

}

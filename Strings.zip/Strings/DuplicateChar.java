package Strings;

public class DuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String str="programming";
         String result="";
         
         for(int i=0;i<str.length();i++) {
        	 boolean duplicate=false;
        	 
        	 for(int j=0;j<i;j++) {
        		 if(str.charAt(i)==str.charAt(j)) {
        			 duplicate=true;
        			 break;
        		 
        		 }
        	 }
        	 if(!duplicate) {
        		 result=result+str.charAt(i);
        	 }
         }
         System.out.println(str);
         System.out.println(result);
	}

}

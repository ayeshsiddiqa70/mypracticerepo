package Strings;

public class FirstNotRepeated {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String str="programming";
        char ch=' ';
        for(int i=0;i<str.length();i++) {
        	
        	int count=0;
        	
        	for(int j=0;j<str.length();j++) {
        		if(str.charAt(i)==str.charAt(j)) {
        			count ++;
        			
        		}
        	}
        	if(count==1) {
        		ch=str.charAt(i);
        		break;
        	}
        }
        System.out.println(ch);
	}

}

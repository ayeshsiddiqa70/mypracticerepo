package Array;

public class leftRotateArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int arr[]= {10,20,30,40,50};
          int k=2;
          
          System.out.println("left rotata array:");
          
          for(int i=1;i<=k;i++) {
        	  int first=arr[0];
        	  
        	  for(int j=0;j<arr.length-1; j++) {
        		  arr[j]=arr[j+1];
        	  }
        	  arr[arr.length-1]=first;
        	  
          }
          
          for(int i=0;i<arr.length;i++) {
        	  System.out.println(arr[i]+"");
          }
	}
	

}

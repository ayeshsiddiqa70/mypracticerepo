package Array;

public class moveZeroes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int arr[]= {10,0,20,0,30,40,0};
          int index=0;
          for(int i=0;i<arr.length;i++) {
        	   if(arr[i]!=0) {
        		   arr[index]=arr[i];
        		   index++;   
        		  
        	  }}
        	   while(index<arr.length) {
        		   arr[index]=0;
        		   index++;
        	   }
        	   System.out.println("Array after moving zeroes");
        	   for(int i=0;i<arr.length;i++) {
        		   System.out.println(arr[i]+"");
        	   }
          }
	}



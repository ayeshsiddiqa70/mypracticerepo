package Array;

public class paiSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int arr[]= {2,4,7,5,9,1};
        int target=10;
        System.out.println("pairs with sum"+target+":");
        
        
        for (int i=0;i<arr.length;i++) {
        	for(int j=i+1;j<arr.length;j++) {
        		if(arr[i]+arr[j]==target) {
        			System.out.println(arr[i]+"+"+arr[j]+"="+target);
        		}
        	}
        	
        }
	}

}

package Array;

public class secondLargest {

	public static void main(String[] args) {
		int arr[]= {10,25,5,40,15};
		
		int largest=arr[0];// first element 10  i=0 arr[i]=10
		int SecondLargest=arr[0]; // first element 10
		
		for(int i=0; i<arr.length; i++) {
			
			if(arr[i]>largest) {
				SecondLargest=largest; //10
				largest=arr[i];        //25
			}	else if(arr[i]>SecondLargest && arr[i]!=largest) {
				SecondLargest=arr[i];
			}
			
		}
		System.out.println("Largest element" +largest);
		System.out.println("SecondLargest element" +SecondLargest);

	}

}

package Array;

public class Largestandsmallestnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int []arr= {10,25,2,655};
        
        int largest=arr[0];
        int smallest=arr[0];
        
        for(int i=0;i<arr.length;i++) {
        	if(arr[i]>largest) {
        		largest=arr[i];
        	}
        	
        	if(arr[i]<smallest) {
        		smallest=arr[i];
        	}
        }
        System.out.println("Largest element"+ largest);
        System.out.println("Smallest element"+smallest);
	}

}

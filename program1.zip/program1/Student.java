
//10
package program1;

public class Student {
	static String collegeName="Jan";
	 String Name;
	 int rollNo;
	 
	 Student(String n, int r){
		Name=n;
		rollNo=r;
	 }
	 
	 void display() {
		 System.out.println("Student Collegename "+collegeName);
		 System.out.println("Student name" +Name);
		 System.out.println("RollNo"+ rollNo);
	 }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Student obj= new Student("Asha",11);
      obj.display();
      Student obj1=new Student("Anil",12);
      obj1.display();
        
	}

}

package program1;

public class Engine {
	void engineInfo() {
		System.out.println("Engine: 4-cylinder,Petrol Engine");
	}
		
	
public class Car{
	Engine eng;
	Car (Engine eng){
		this.eng=eng;
	
}
	void display() {
		System.out.println("car details");
		eng.engineInfo();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Engine e1=new Engine();
		Car c1=new Car(e1);
		c1.display();
		

	}

}

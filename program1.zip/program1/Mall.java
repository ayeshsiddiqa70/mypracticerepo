
//23
package program1;

public class Mall {
	
	Mall(){
		System.out.println("Welcome to the Mall");
		
	}
	
	Mall(String s){
		this();
		System.out.println("shopping");
	}

	public static void main(String[] args) {
        Mall m= new Mall("s");
	}

}

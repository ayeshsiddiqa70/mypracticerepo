package program1;

public class Vehicle {
	void fuelType() {
		System.out.println("Run on fuel");
	}}
	
	class ElectricCar extends Vehicle{
		void fuelType() {
			System.out.println("Run on electricity");
		}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Vehicle v=new Vehicle();
         v.fuelType();
         ElectricCar e=new ElectricCar();
         e.fuelType();
	}

}


//13
package program1;

public class Device {
	
	void start() {
		System.out.println("Started");
	}}
class Mobile extends Device{
	void calling() {
		System.out.println("Calling");
	}
	
}
class SmartPhone extends Mobile{
	void internet() {
		System.out.println("Internet");
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
      SmartPhone obj=new SmartPhone();
      obj.internet();
      obj.calling();
      obj.start();
	}

}

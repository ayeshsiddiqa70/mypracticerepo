package program1;

public class Employee {
	
	private int empId;
	private String empName;
	private double Salary;
	
	void setempId(int id) {
		empId=id;
	}
	
	void setempName(String name) {
		empName=name;
	}
	
	void setSalary(double sal) {
		Salary=sal;
	}
	
	int getempId() {
		return empId;
	}
	
	String getempName() {
		return empName;
	}
	
	double getSalary() {
		return Salary;
	}
	
	void displayDetails() {
		System.out.println("EmployeeeId"+ getempId());
		System.out.println("EmployeeName"+ getempName());
		System.out.println("Salary"+ getSalary());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Employee emp=new Employee();
    emp.setempId(1234);
    emp.setempName("Neha");
    emp.setSalary(15000);
    
    emp.displayDetails();
	}

}

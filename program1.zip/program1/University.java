
//21
package program1;

public class University {
  static String Country="India";
  String universityName;
  
  University(String name){
	universityName=name;
  }
  void display() {
	  System.out.println("University Name:" +universityName);
	  System.out.println("Country Name:" +Country);
  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		University u1=new University("Bangalore University");
	 
	     u1.display();
	    u1.display();    
	

	}

}

//16

package program1;

public class Hospital {
   
	void emergencyService() {
		System.out.println("Emergency serice");
	}
	
	
	class CityHospital extends Hospital{
		void emergencyService() {
			super.emergencyService();
			 System.out.println("City Hospital provides advanced emergency services");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       CityHospital ch=new CityHospital();
       ch.emergencyService();
	}
}


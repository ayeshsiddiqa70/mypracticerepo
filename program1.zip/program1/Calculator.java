package program1;

public class Calculator {
	
	
	void add(int a , int b) {
		int c=a+b;
		System.out.println("sum of numbers " +c);
	}
	
	void add(double a, double b) {
		double z=a+b;
		System.out.println("Sum of numbers" +z);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 Calculator c1=new Calculator();
	 c1.add(11.5,12.5);
	 c1.add(1, 3);
	 

	}

}

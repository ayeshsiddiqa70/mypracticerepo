
//19
package program1;

public class Camera {
  
	void capture() {
		System.out.println("clicked");
	}
	
	class DSLCamera extends Camera{
		void capture() {
			System.out.println("DSL");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Camera DSL= new DSLCamera();
  DSL.capture();

	}

}

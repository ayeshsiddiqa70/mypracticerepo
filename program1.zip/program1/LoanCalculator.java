//15
package program1;

public class LoanCalculator {
	void calculateLoan(int amount) {
		System.out.println("Loan amount" +amount);
	}

	void calculateLoan(int amount, double interestRate) {
		System.out.println("Loan amount" +amount+"interest"+interestRate);
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
      LoanCalculator obj=new LoanCalculator();
      obj.calculateLoan(5000000);
      obj.calculateLoan(5000000, 10.5);
	}

}

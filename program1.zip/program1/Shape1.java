package program1;

public class Shape1 {
	
	void area() {
		System.out.println("area of");
	}
	
	class Rectangle extends Shape1{
		void area() {
			int length = 5;
	        int width = 4;

	        int result = length * width;

	        System.out.println("Area of Rectangle: " + result);
			
		}
	}
 
	class Circle extends Shape1{
		void area() {
			double radius = 3;

	        double result = 3.14 * radius * radius;

	        System.out.println("Area of Circle: " + result);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Shape1 s=new Rectangle();
          s.area();
          Shape1 s1=new Circle();
          s.area();
	}

}

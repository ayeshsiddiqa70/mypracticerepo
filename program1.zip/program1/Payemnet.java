
//6
package program1;



public interface Payemnet {
	void makePayment(); 
	}
class UPI implements Payemnet{
	public void makePayment() {
		System.out.println("upi payrment succees");
		}

class CreditCard implements Payemnet{
		 public void makePayement() {
				System.out.println("creditcard  payrment succees");

			 
		 }
	
}	
	public static void main(String[] args) {
		Payemnet obj =new UPI();
		obj.makePayment();
		
		Payemnet obj1=new CreditCard();
		obj1.makePayment();
		
	}
}




//24
package program1;

public class Shape {
	
	double length;
	
 void Square(double side) {
	 length=side;
	 double area=length * length;
	 System.out.println("Area of Square:" +area);
	 
 }
 void Rectangle(double l, double b) {
	 double area=l*b;
	 System.out.println("Area of rectangle" +area);
 }
 
 void circle(double radius) {
	 double area=Math.PI * radius * radius;
	 System.out.println("Area of circle" +area);
	 
 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape obj=new Shape();
		obj.Square(4);
		obj.Rectangle(5,3);
		obj.circle(4.5);
		

	}

}

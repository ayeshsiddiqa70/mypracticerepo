//9
package program1;

public class Bank {
	final String IFSC="SBI000";
	 
	final void showIFSC() {
		System.out.println("IFSC"+ IFSC);
	}
	
class HDFCBank  extends Bank{
	void showIFSC() {
		System.out.println("HDFC IFSC");
	}
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HDFCBank obj=new HDFCBank();
		obj.showIFSC();
		

	}

}

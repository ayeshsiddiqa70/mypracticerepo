package program1;

public class Account {
	
	private String accountHolderName;
	private double balance;
	
	void setAccountHolderName(String name) {
		accountHolderName=name;
	}

	String getAccountHolderName() {
		return accountHolderName;
	}
	
	void setBalance(double bal) {
		 if(bal<0) {
			 System.out.println("Balance cannot be negative");
		 }
		 else {
			 balance=bal;
		 }
	}
	
	double getBalance() {
		return balance;
	}
	
	void displayDetails() {
		System.out.println("AccountHolderName"+ getAccountHolderName());
		System.out.println("Balance"+getBalance());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Account ac=new Account();
		ac.setAccountHolderName("Asha");
		ac.setBalance(20000);
		ac.setBalance(-240);
		
		ac.displayDetails();
		

	}

}

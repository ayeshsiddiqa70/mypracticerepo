
//25
package program1;

 class School1 {
	 // Instance variable
		String name;
		 // Default constructor
		School1(){
			name="JPM";
			System.out.println("School name:"+name);
		}
		  // Method to display message
		void display() {
			System.out.println( "This School is based out of Kolkata");
		}
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating object (constructor gets called automatically)
       School1 S1=new School1();
       // Calling method
       S1.display();
       
       
	}

}

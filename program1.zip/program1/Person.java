//7

package program1;

public class Person {
	
	Person(){
		System.out.println("Person Created");
	}
	
	class Student extends Person{
		Student() {
			super();
			System.out.println("Student Created");
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Student s=new Student();
	}

}

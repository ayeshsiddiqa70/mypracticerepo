package program1;

public class Product {
  
	int productId;
	String productName;
	int price;
	 
	Product(){
		System.out.println("Product Created");
	}
	Product(int i, String n, int p){
		productId=i;
		productName=n;
		price=p;
	}
	
	void displayProduct() {
		System.out.println(productId+" "+productName+" "+price);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Product p=new Product();
       Product p1=new Product(143,"Teac",48);
       p.displayProduct();
       p1.displayProduct();
	}

}

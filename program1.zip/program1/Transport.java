//18
package program1;

 interface Transport {
	void booking();
	}
class Bus implements Transport
{
	public void booking() {
		System.out.println("Travel through bus");
		

	}}

class Flight implements Transport
{
	public void booking() {
		System.out.println("FLight booked");
	}
	public static void main(String[] args) {
		Transport t1=new Bus();
		t1.booking();
		Transport t2=new Flight();
		t2.booking();
	}
}

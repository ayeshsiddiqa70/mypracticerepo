//26

package program1;

class School {

    String name;
    String address;
    int strength;

    // Constructor with 2 variables
    School(String n, String a) {
        name = n;
        address = a;
        
    }

    // Constructor with 3 variables
    School(String n, String a, int s) {
        name = n;
        address = a;
        strength = s;
    }

    void display() {
        System.out.println(name + " " + address + " " + strength);
    }

    public static void main(String[] args) {

        School S1 = new School("Anil", "JPM");   // 2 parameter
        School S2 = new School("Ayan", "SG", 7); // 3 parameter

        S1.display();
        S2.display();
    }
}
//11

package program1;

public class Library {
	String libraryName;
	void display() {
		System.out.println("Welcome to library");
	}
	
	void showLocation() {
		System.out.println("This library is located in Mumbai");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Library obj=new Library();
         obj.display();
         obj.showLocation();
	}

}

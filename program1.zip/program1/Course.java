package program1;

public class Course {
	void courseInfo() {
		System.out.println("All COurses");
	}
	
	class Science extends Course{
		void course1() {
			System.out.println("Science course");
			
		}
	}
	class Commerce extends Course{
		void course2() {
			System.out.println("Commerce course");
		}
	}
	
	class Arts extends Course{
		void course3() {
			System.out.println("Arts Course");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Science obj1=new Science();
		obj1.courseInfo();
		obj1.course1();
		Commerce obj2=new Commerce();
		obj2.courseInfo();
		obj2.course2();
          Arts obj=new Arts();
          obj.courseInfo();
          obj.course3();
	}
	}



//22
package program1;

public class GovernmentRules {
	
	final int MAX_WORKING_HOURS = 8;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GovernmentRules obj =new GovernmentRules();
		System.out.println("Max working hr" + obj.MAX_WORKING_HOURS);
		
		//obj.MAX_WORKING_HOURS = 10;
	}

}

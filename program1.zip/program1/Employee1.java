package program1;

abstract class Employee1 {
	
	abstract void calculateSalary();

    // Concrete method
    void employeeDetails() {
        System.out.println("Employee details displayed");
    }
}

// FullTimeEmployee class
class FullTimeEmployee extends Employee {

    void calculateSalary() {
        int salary = 50000;
        System.out.println("Full Time Employee Salary: " + salary);
    }
}

// PartTimeEmployee class
class PartTimeEmployee extends Employee {

    void calculateSalary() {
        int hours = 5;
        int ratePerHour = 500;
        int salary = hours * ratePerHour;

        System.out.println("Part Time Employee Salary: " + salary);
    }

    public static void main(String[] args) {

        // Full time employee object
        Employee e1 = new FullTimeEmployee();
        e1.employeeDetails();
        e1.calculateSalary();

        System.out.println("----------------");

        // Part time employee object
        Employee e2 = new PartTimeEmployee();
        e2.employeeDetails();
        e2.calculateSalary();
    }
}
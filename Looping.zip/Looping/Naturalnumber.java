package Looping;

public class Naturalnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int n=5;
        int i=1;
        int sum=0;
        
        while(i<=n) {
        	sum=sum+i;
        	i++;
        }
        System.out.println("Sum="+sum);
	}

}

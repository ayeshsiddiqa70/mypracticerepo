package Looping;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int num=121;
        int act=num;
        int rev=0;
        
        while(num!=0) {
        	int d=num%10;
        	rev=rev*10+d;
        	num=num/10;
        }
        System.out.println(rev);
        
        if(act==rev) 
        {
        	System.out.println("The number is Palindrome");
        }
        	else {
        		System.out.println("The number is not a Palindrome");
        	}
        	
        }
	}



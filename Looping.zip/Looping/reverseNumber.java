package Looping;

public class reverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int num=1234;
        int rev=0;
        
        while(num!=0) {
        	int d=num%10;
        	rev=rev*10+d;
        	num=num/10;
        }
        System.out.println(rev);
        
        
        	
        }
	}



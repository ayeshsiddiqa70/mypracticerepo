package Looping;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int choice;
       Scanner sc=new Scanner(System.in);
       
       do {
    	   System.out.println("****----Calculator Menu-----****\n");
    	   System.out.println("1-Addition");
    	   System.out.println("2-Subtraction");
    	   System.out.println("3-Multiplication");
    	   System.out.println("4-Division");
    	   System.out.println("5-Exit");
    	   System.out.println("Enter Your Choice");
           choice=sc.nextInt();
           if(choice>=1 && choice<=4) {
        	   System.out.println("Enter First number");
        	   double a=sc.nextDouble();
        	   System.out.println("Enter Second number");
        	   double b=sc.nextDouble();
        	   switch(choice) {
        	   case 1:
        		   System.out.println("Result is "+(a+b));
        		   break;
        	   case 2:
        		   System.out.println("Result is "+(a-b));
        		   break;
        	   case 3:
        		   System.out.println("Result is "+(a*b));
        		   break;
        	   case 4:
        		   System.out.println("Result is "+(a/b));
        		   break;
        		   default:
        			   System.out.println("You have entered an invalid choice");
        	   }
           }
           
           else if(choice==5) {
        	   System.out.println("Exiting from callculator Program");
        	  break;
           }
         
    	   
       } while(choice!=5);
       
	}

}

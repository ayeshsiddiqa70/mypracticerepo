package Looping;

public class PositiveNegativeZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int num=-5;
          
          if(num<0) {
        	  System.out.println("number is negative");
          }
        	  else if(num>0) {
        		  System.out.println("number is positive");
        	  }
        	  else {
        		  System.out.println("number is zero");
        	  }
        	  
          }
	}


